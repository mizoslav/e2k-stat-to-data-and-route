#include <time.h>
#include <string.h>
#include <stdio.h>

char *zaznam[15];	// jeden 15 riadkovy letovy zaznam zo STAT<DDMMYY>
char nameofile[11];
char RunDir[60], LogFile[60];
char FDP1_file[60], FDP2_file[60];

// Staticka datova struktura 'let' sluzi na pracu s jednym FDR.
struct {
	char id[4];
	int status;
	char ident[11];
	int mod_ssr;
	char kod_ssr[5];
	char F_rules;
	char F_type;
	char AC_num[3];
	char AC_type[5];
	char w_turbulence;
	char com_nav_equip[80];
	char SSR_equip[30];
	char registration_text[201];
	char operator_text[201];
	char STS_text[201];
	char remark_text[701];
	char adep[5];
	char etd[6];
	char take_off_RWY[4];
	char entry_point[12];
	char entry_time[6];
	char cruising_speed[6];
	char requested_FL[5];
	char ades[5];
	char eet[6];
	char landing_RWY[4];
	char exit_point[12];
	char exit_time[6];
	char route_length[5];
	char route[761];
} let;

#define MAX_FLIGHTS_PER_DAY 2500
// Staticka datova struktura 'prehlad' sluzi ako evidencia jedinecnych FDR,
// ktore identifikuje na zaklade UID a ACID
// Je dimenzovana pre max. pocet zaznamov v subore 'STAT<DDMMYY>' (2500)!!!
// Subory 'STAT<DDMMYY>' pochadzaju z oboch uzlov FDP (A/B) a do pracovneho
// adresara su prenesene volanim externeho shell-scriptu 'rcopy'.
struct {
	int poradie;
	char uid[4];
	char ident[11];
	int status_fdp1;
	int status_fdp2;
} prehlad[MAX_FLIGHTS_PER_DAY];

int main(int argc, char *argv[]) {

	FILE *fp, *fw, *fw1, *flog;
	int c, i, nasiel, pocet, pokracuj, poradie;
	int pocet_letov_1, pocet_letov_2, nletov, nporadie;
	char subor[25], datum[11], system_call[20];
	char outfile[32], outroute[32];


	zaznam[00] = (char *) malloc(32);
	zaznam[01] = (char *) malloc(20);
	zaznam[02] = (char *) malloc(9);
	zaznam[03] = (char *) malloc(110);
	zaznam[04] = (char *) malloc(201);
	zaznam[05] = (char *) malloc(201);
	zaznam[06] = (char *) malloc(201);
	zaznam[07] = (char *) malloc(701);
	zaznam[08] = (char *) malloc(13);
	zaznam[09] = (char *) malloc(17);
	zaznam[10] = (char *) malloc(10);
	zaznam[11] = (char *) malloc(13);
	zaznam[12] = (char *) malloc(17);
	zaznam[13] = (char *) malloc(761);
	zaznam[14] = (char *) malloc(5);

	strcpy(RunDir,"/usr/users/stat/");
	strcpy(LogFile,"/usr/users/stat/prevod.log");
	strcpy(FDP1_file,RunDir);strcat(FDP1_file,"brfdp_a");
	strcpy(FDP2_file,RunDir);strcat(FDP2_file,"brfdp_b");
	strcpy(let.id,  "");
	strcpy(nameofile, "");

	strcpy(system_call, RunDir);strcat(system_call,"rcopy ");
	strcpy(outfile, RunDir);strcat(outfile,"data");
	strcpy(outroute, RunDir);strcat(outroute,"route");
	subor[0]='\0';
	nasiel = 0;
	pocet = 0;
	pocet_letov_1 = 0;
	pocet_letov_2 = 0;
	nporadie=0;
	nletov = 0;
	pokracuj = 0;

	// normalizuj ARGC, t.j. aby zodpovedal poctu argumentov ARGV[]
	argc--;

	// ak je program volany s argumentom DATE
	if (argc) {
		// v tvare DDMMYY (nedokonaly test na zhodu datumoveho formatu)
		if (strlen(argv[1]) == 6 ) {
			// set 'nameofile' to DATE in form DDMMYY
			strcpy(nameofile, argv[1]); 
			// set 'subor' to STAT<DDMMYY>
			strcpy(subor, "STAT");
			strcat(subor, argv[1]);
		}
		// ak DATE nie je v tvare DDMMYY (6 znakov)
		else {
			printf("%s: error: invalid date\n", argv[0]);
			printf("usage: %s [DATE]\n\nwhere DATE is in form DDMMYY\n", argv[0]);
			return 0;
		}
	}
	// ak je program volany bez argumentu, tak default DATE = yesterday
	else {
		// set 'nameofile' to yesterday's date in form DDMMYY
		daj_datum(nameofile);
		// set 'subor' to STAT<yesterday>
		strcpy(subor, "STAT");
		strcat(subor, nameofile);
	}
	strcat(system_call, subor);
	// call '<RunDir>/rcopy STAT<DATE>'
	system(system_call);  

	// set 'datum' to <DD>.<MM>.<YYYY> according to <DDMMYY>
	urob_datum(datum, nameofile);
	// set DATE to 'YYMMDD'
	obrat_datum(nameofile);
	// set 'outfile' to <RunDir>/data<YYMMDD>
	strcat(outfile, nameofile);
	// set 'outroute' to <RunDir>/route<YYMMDD>
	strcat(outroute, nameofile);
	//FP
	//printf("LogFile:%s\n", LogFile );
	flog=fopen(LogFile,"w");
	fprintf(flog, "Datum %s\n", datum );
	//printf("Datum %s\n", datum );
	printf("Datum %s\n", datum );
	fprintf(flog, "Output files: %s  %s \n", outfile, outroute );
	printf("Output files: %s  %s \n", outfile, outroute );
	fclose(flog);

	if ((fw=fopen(outfile,"w")) == NULL) {
		printf("Nemozem otvorit vystupny subor '%s'!\n", outfile);
		chyba(2);
	}

	if ((fw1=fopen(outroute,"w")) == NULL) {
		printf("Nemozem otvorit vystupny subor '%s'!\n", outroute);
		exit(1);
	}

	for (i = 0; i < MAX_FLIGHTS_PER_DAY; i++) 
		prehlad[i].status_fdp1 = prehlad[i].status_fdp2 = -1;
	//FP
	//printf("Otvaram FDP1_file:%s\n", FDP1_file );
	// Open file 'FDP-A.STAT<DDMMYY>' to process FDR's...
	if ((fp=fopen(FDP1_file, "r")) == NULL)	chyba(3);

	do {
		c = getc(fp);
		if (c == '\n') continue;
		if (c == '(') {
			pokracuj = daj_zaznam(fp);
			// ak je zaznam vadny, tak zvys pocet vadnych zaznamov o jeden
			if (pokracuj == 1)
				pocet++;
			else {
				// urob z vety strukturu dat
				daj_strukturu();
				//vypis_strukturu(); 

				// pridaj do prehladovej tabulky tento let
				pridaj(nporadie++, 0);

				// ak je let v stave OPERATIONAL,
				// tak zapis let do vystupneho suboru s por.cislom nletov
				if (let.status == 0) zapis_data(fw, fw1, nletov++, datum);

				// zvys pocet letov prevzatych z FDP-A o jeden
				pocet_letov_1++;
			}
		}

		// Ak je koniec suboru, tak nastav priznak pokracovania na NIE
		if ( c ==  EOF ) pokracuj = 1;
	} while (pokracuj == 0);

	fclose(fp);
	//FP
	//printf("zatvaram FDP1_file:%s\n", FDP1_file );

	if (argc == 2)
		strcpy(subor, argv[2]);
	else  
		strcpy(subor, "/usr/users/stat/brfdp_b");

	//FP
	printf("Otvaram FDP2_file:%s\n", FDP2_file);
	// otvorenie a spracovanie subor FDP2
	if ((fp=fopen(FDP2_file,"r")) != NULL) {
		do {
			c = getc(fp);
			if (c == '\n') continue;
			if (c == '(') {
				pokracuj = daj_zaznam(fp);
				// ak je zaznam vadny
				if (pokracuj == 1)
					// zvys pocet vadnych zaznamov o jeden
					pocet++;
				else {
					// inak
					daj_strukturu();
					poradie = daj_poradie(nporadie);

					// ak let este nie je v prehlade letov, t.j. je nezapisany
					if ( poradie == -1 ) {
						// tak ho zapis
						pridaj(nporadie++, 1);
						// printf("Zapisujem!  status=%d %s\n", let.status, let.ident);
						zapis_data( fw, fw1, nletov++, datum );
					}
					else
						if ( let.status == 0 ) {
							// printf("Zapisujem!  status=%d %s\n", let.status, let.ident );
							zapis_data( fw, fw1, nletov++, datum );
							prehlad[poradie].status_fdp2 = let.status;
						}
						else {
							prehlad[poradie].status_fdp2 = let.status;
							// printf("Update letu %s status=%d\n", let.ident, let.status);
						}
					pocet_letov_2++;
				}
			}
			if (c ==  EOF) pokracuj = 1;
		} while (pokracuj == 0);
	}

	//strcpy(subor, "/usr/users/stat/brfdp_a");
	// opatovne prezretie suboru z FDP1
	if ((fp = fopen(FDP1_file, "r")) != NULL) {
		do {
			c = getc(fp);
			if (c == '\n') continue;
			if (c == '(') {
				pokracuj = daj_zaznam(fp);
				if (pokracuj == 1)
					;
				else {
					daj_strukturu();
					poradie = daj_poradie(nporadie);
					if (poradie == -1) chyba(99);
					if ((prehlad[poradie].status_fdp1 == 0) || \
						(prehlad[poradie].status_fdp2 == 0))
						;
					else {
						if ((prehlad[poradie].status_fdp1 > 0)) {
							if (prehlad[poradie].status_fdp2 != 0) {
								zapis_data( fw, fw1, nletov++, datum );
								//printf("Pridavam let %s !",let.ident);
							}
						}
					}
				}
			}
			if (c == EOF) pokracuj = 1;
		} while ( pokracuj == 0 );
	}
	
	fclose(fp);
	fclose(fw);
	fclose(fw1);
	
	flog = fopen(LogFile, "a");
	fprintf(flog, "\nCelkovy pocet zaznamov %d\n", nletov);
	fprintf(flog, "\nPocet zaznamov v FDP1 %d\n", pocet_letov_1);
	fprintf(flog, "\nPocet zaznamov v FDP2 %d\n", pocet_letov_2);
	fprintf(flog, "\nPocet chybnych zaznamov %d\n", pocet);
	fclose(flog); 
/*  for ( i = 0; i < nletov ; i++ )
printf("%3d %3s %10s %1d %1d\n", prehlad[i].poradie, prehlad[i].uid, prehlad[i].ident, prehlad[i].status_fdp1, prehlad[i].status_fdp2 );
*/
}
// end of main() ===============================================================

daj_zaznam(FILE *fp)
{
 char c, retazec[1000];
 int nasiel, riadok, i;

 nasiel = 0;
 riadok = 0;
 i = 0;
//FP
//printf(" Start daj_zaznam --->\n");

 while (( c = getc(fp)) != EOF ) {
     if (c == '\n') {
           retazec[i] = '\0';
           strcpy(zaznam[riadok], retazec);
 // printf(" -->zaznam[%d]=%s,%d\n", riadok, retazec, strlen(retazec));  //FP
           riadok++;
           i = 0;
     } else
           if (c == ')') {
              retazec[i] = '\0';
              strcpy(zaznam[riadok], retazec);
  //printf(" -->zaznam[%d]=%s,%d\n", riadok, retazec, strlen(retazec));  //FP
              if (riadok == 14)
                 return (0);
              else
                 return (1);
           }
           else
              retazec[i++] = c;
 }
 return(1);
}

 
daj_strukturu()
{
 int i,j;
 char pomstr[1000];

//FP
//printf("-------------> START daj_strukturu\n");

 i = j = 0; 
 while ( zaznam[0][i] != ' ')                  /* preskoc frazu STAT */
   i++;
 
 i++;
 while ( zaznam[0][i] != ' ' )                 /* kopiruj znaky id cisla */
    pomstr[j++]=zaznam[0][i++];                /* az po znak medzera */
 pomstr[j] = '\0';
 i++;
 strcpy(let.id, pomstr);                    /* prepis id cislo do struktury */


 j=0;
 while ( zaznam[0][i] != ' ' )                 /* kopiruj znaky statusu az po medzeru */
    pomstr[j++]=zaznam[0][i++];
 pomstr[j] = '\0';

 if (strcmp(pomstr, "OPERATIONAL") == 0 )   /* ak je status OPER */
    let.status = 0;                         /* uloz do struktury hodnotu 0 */
 else
 if (strcmp(pomstr, "STAND_BY") == 0 )      /* ak je status STANDBY */
    let.status = 1;                         /* uloz do struktury hodnotu 1 */
 else
    let.status = 2;                         /* inak je status NEDEF */


 i = j = 0;
 while ( zaznam[1][i] != '/')               /* az po znak '/' kopiruj znaky */
    pomstr[j++]=zaznam[1][i++];
 pomstr[j]='\0';

 
 strcpy(let.ident, pomstr);                 /* uloz retazec do struktury */
//FP
//printf(" let.ident-->%s\n",let.ident);

 i++;
 if (zaznam[1][i] == '?')
    let.mod_ssr = '\0';
 else
    let.mod_ssr = zaznam[1][i++];           /* uloz do struktury znak modu ssr */
 
 j=0;
 while ( zaznam[1][i] != ' ')
    pomstr[j++]=zaznam[1][i++];
 pomstr[j]='\0';

 if (pomstr[0] == '?')
    let.kod_ssr[0] = '\0';
 else
     strcpy(let.kod_ssr, pomstr);           /* uloz do struktury kod SSR */
 i++;

 if (zaznam[1][i] == '?')
    let.F_rules = '\0';
 else
    let.F_rules = zaznam[1][i++];           /* uloz do struktury pravidla letu */

 if (zaznam[1][i] == '?')
    let.F_type = '\0';
 else 
    let.F_type  = zaznam[1][i];             /* uloz typ letu */


 j = i = 0;
 while ( isdigit(zaznam[2][i]) != 0 )
    pomstr[j++] = zaznam[2][i++];
 pomstr[j] = '\0';


 if ( pomstr[0] == '?' )
    let.AC_num[0] = '\0';
 else
    strcpy(let.AC_num, pomstr);             /* uloz pocet lietadiel */          

 j = 0;
 while ( zaznam[2][i] != '/' )
    pomstr[j++] = zaznam[2][i++];
 pomstr[j] = '\0';

 if ( pomstr[0] == '?' )
    let.AC_type[0] = '\0';
 else
    strcpy(let.AC_type, pomstr);            /* uloz typ lietadla */ 

 if ( zaznam[2][i] == '?' )
    let.w_turbulence = '\0';
 else
    let.w_turbulence = zaznam[2][++i];      /* uloz turbulenciu */

 i = j = 0;
 while ( zaznam[3][i] != '/' )
    pomstr[j++] = zaznam[3][i++];
 pomstr[j] = '\0';

 if ( pomstr[0] == '?' )
   let.com_nav_equip[0] = '\0';
 else 
   strcpy( let.com_nav_equip, pomstr);     /* uloz navig. zariadenia */

//FP
//printf("zaznam[3]:%s\n", zaznam[3]);
//printf("let.com_nav_equip:%s\n", let.com_nav_equip);

 if ( zaznam[3][++i] == '?' ){
   let.SSR_equip[0] = '\0';
 }else{
  // let.SSR_equip = zaznam[3][i];           /* uloz typ odpovedaca */
  j = 0;
  while (isalnum(zaznam[3][i])) 
        pomstr[j++] = zaznam[3][i++];
  
  pomstr[j] = '\0';
  strcpy(let.SSR_equip,pomstr); 
  //printf("let.SSR_equip:%s\n", let.SSR_equip);
 }
    

 aright(zaznam[4],4);                      /* vyhod retazec REG/  */
/* 
 if ( strlen( zaznam[4] ) > 8 )            takto to fungovalo do 17.8.2006
					   potom sa vyskytla chyba pri obdrzani
				           msg s polom REG > ako 8 znakov
					   Po konzultacii s Romanom Kuceerom na
				    	   max. 14 znakov upravil MIZO.
*/
 if ( strlen( zaznam[4] ) > 14 )           /* ak dlzka retazca je vacsia ako 14 */
    chyba(1);                              /* ukonci program s chybovym hlasenim */

 strcpy( let.registration_text, zaznam[4]); /* uloz registraciu */
//FP
//printf("let.registration_text=%s\n",let.registration_text);

 aright(zaznam[5],4);                       /* vyhod retazec OPR/ */
 strcpy( let.operator_text, zaznam[5]);     /* uloz opratora    */
//FP
//printf("let.operator_text=%s\n",let.operator_text);

 aright(zaznam[6],4);                       /* vyhod retazec STS/ */
 strcpy( let.STS_text, zaznam[6]);          /* uloz STS_text    */
//FP
//printf("let.STS_text=%s\n",let.STS_text);
//printf(" zaznam[7]=%s\n",zaznam[7]);

 aright(zaznam[7],4);                       /* vyhod retazec RMK/ */

 strcpy( let.remark_text, zaznam[7]);       /* uloz poznamku    */
//FP
//printf("let.remark_text=%s\n",let.remark_text);

 if ( zaznam[8][0] == '?' ){
    let.adep[0] = '\0';
 }else{
    strncpy ( let.adep, zaznam[8], 4 );     /* uloz letisko startu */
    let.adep[4]='\0';
 }
 
//FP
//printf("let.adep=%s\n",let.adep);

 i=4;
 j=0;
 while ( zaznam[8][i] != ' ' )
    pomstr[j++] = zaznam[8][i++];
 pomstr[j] = '\0';

 if ( pomstr[0] == '?' )
   let.etd[0] = '\0';
 else {
        strcpy( let.etd, pomstr);           /*  uloz cas startu */
        urob_hodiny(let.etd);               /*  oprav cas na tvar HH:MM */
 }
//FP
//printf("let.etd=%s\n",let.etd);

 j = 0;
 i++;
 while ( (pomstr[j++]=zaznam[8][i++]) != '\0' )
     ;

 if ( pomstr[0] == '?' )
   let.take_off_RWY[0] = '\0';
 else
   strcpy ( let.take_off_RWY, pomstr );     /* uloz odletovu drahu */
 
 j = i = 0;

 while ( zaznam[9][i] != ' ' )
    pomstr[j++] = zaznam[9][i++];
 pomstr[j] = '\0';

 if ( pomstr[0] == '?' )
    let.entry_point[0] = '\0';
 else
    strcpy( let.entry_point, pomstr);       /* uloz vstupny bod */

//FP
//printf("let.entry_point=%s\n",let.entry_point);

 i++;
 j = 0;

 while ( (pomstr[j++]=zaznam[9][i++]) != '\0' )
    ;
 
 if ( pomstr[0] == '?' )
    let.entry_time[0] = '\0';
 else {
       strcpy( let.entry_time, pomstr);     /* uloz cas na vstupnom bode */
       urob_hodiny(let.entry_time);         /* a konvertuj ho na tvar HH:MM */
 }

 i=1;
 j=0;
 while ( isdigit(zaznam[10][i]) != 0 )
    pomstr[j++] = zaznam[10][i++];
 pomstr[j]='\0';


 i++;
 j=0;
 if ( pomstr[0] == '?' )
    let.cruising_speed[0] = '\0';
 else
    strcpy ( let.cruising_speed, pomstr );  /*  uloz cestovnu rychlost */

 while ( (pomstr[j++]=zaznam[10][i++]) != '\0' )
     ;
 pomstr[j]='\0';
 if ( pomstr[0] == '?' )
    let.requested_FL[0] = '\0';
 else
    strcpy ( let.requested_FL, pomstr);     /* uloz cestovnu hladinu */
 
 if ( zaznam[11][0] == '?' )
    let.ades[0] == '\0';
 else 
    strncpy ( let.ades, zaznam[11], 4 );    /* uloz cielove letisko */

 i=4;
 j=0;
 while ( zaznam[11][i] != ' ' )
    pomstr[j++] = zaznam[11][i++];
 pomstr[j] = '\0';

 if ( pomstr[0] == '?' )
    let.eet[0] = '\0';
 else {
    strcpy( let.eet, pomstr);               /* uloz cas pristatia */
    urob_hodiny(let.eet);                   /* a konnertuj ho na HH:MM */
 }

 j = 0;
 i++;
 while ( (pomstr[j++]=zaznam[11][i++]) != '\0' )
     ;

 if ( pomstr[0] == '?' )
    let.landing_RWY[0] = '\0';
 else
    strcpy ( let.landing_RWY, pomstr );     /*  uloz pristavaciu drahu */

 j = i = 0;

 while ( zaznam[12][i] != ' ' )
    pomstr[j++] = zaznam[12][i++];
 pomstr[j] = '\0';

 if ( pomstr[0] == '?' )
    let.exit_point[0] = '\0';
 else 
    strcpy( let.exit_point, pomstr);         /* uloz vystupny bod */

//FP
//printf("let.exit_point=%s\n",let.exit_point);

 i++;
 j = 0;

 while ( (pomstr[j++]=zaznam[12][i++]) != '\0' )
    ;
 
 if ( pomstr[0] =='?' )
   let.exit_time[0] = '\0';
 else {
      strcpy( let.exit_time, pomstr);       /* uloz cas opustenia FIR */
      urob_hodiny(let.exit_time);           /* a konvertuj ho na tvar HH:MM */
 }
//FP
//printf("let.exit_time=%s\n",let.exit_time);
//printf("zaznam[13]=%s\n",zaznam[13]);
//printf("zaznam[14]=%s\n",zaznam[14]);

 strcpy( let.route, zaznam[13]);
//FP
//printf("let.route=%s\n",let.route);

 strcpy( let.route_length, zaznam[14]);
//FP
//printf("let.route_length=%s\n",let.route_length);
//FP
//printf(" ----------------END daj_strukturu\n");

}
//==============================================================================
vypis_strukturu()
{
	printf("%s %d\n", let.id, let.status);
	printf("%s %c %s\n", let.ident, let.mod_ssr, let.kod_ssr);
	printf("pocet lietadiel : %s\n", let.AC_num);
	printf("typ lietadla : %s\n", let.AC_type);
	printf("turbulencia : %c\n", let.w_turbulence);
	printf("nav. zariadenia : %s\n", let.com_nav_equip);
	printf("typ odpovedaca : %s\n", let.SSR_equip);
	printf("registracia : %s\n", let.registration_text);
	printf("operator : %s\n", let.operator_text);
	printf("STS_text : %s\n", let.STS_text);
	printf("poznamka : %s\n", let.remark_text);
	printf("ADEP : %s\n", let.adep );
	printf("ETD  : %s\n", let.etd );
	printf("takeoff RWY : %s \n", let.take_off_RWY );
	printf("entry point : %s \n", let.entry_point );
	printf("entry time : %s \n", let.entry_time );
	printf("cruising speed : %s\n", let.cruising_speed);
	printf("requisted FL   : %s\n", let.requested_FL);
	printf("ADES : %s \n", let.ades );
	printf("EET : %s \n", let.eet );
	printf("landing RWY : %s \n", let.landing_RWY);
	printf("exit point : %s \n", let.exit_point );
	printf("exit time : %s \n", let.exit_time );
	printf("%s!\n", let.route);
	printf("preletena vzdialenost : %s\n", let.route_length);
return 0;
}

//==============================================================================
// search for 'let' in 'prehlad'
// return the number of record in prehlad[], which matches to let.
daj_poradie(int pocet) {
	int i = 0;

	if (pocet == 0) return 0;

	while (i < pocet){
		if (strcmp( (prehlad[i]).uid, let.id ) == 0 )
		if (strcmp( (prehlad[i]).ident, let.ident ) == 0 ) return i;
		i++;
	}
	printf("Nenasiel som %s\n", let.ident);
	return -1;
}
//==============================================================================
// append the unique flight identifier to data structure 'prehlad[]' 
pridaj(int pocet, int subor) {
	prehlad[pocet].poradie = pocet  + 1;
	strcpy(prehlad[pocet].uid, let.id );
	strcpy(prehlad[pocet].ident, let.ident );
	// if source is node FDP-A, ...
	if (subor == 0)
		prehlad[pocet].status_fdp1 = let.status;
	else
		prehlad[pocet].status_fdp2 = let.status;
}
//==============================================================================
// write N-th FDR stored in 'let' to 'data<YYMMDD>' and 'route<DDMMYY>'
zapis_data(FILE *fw, FILE *fw1, int n, char dat[]) {
	int i, j, porcis;
	char bod[6], level[4], time[6], c;

	fprintf(fw, "%s|%d|%s|%c|%s",dat, n, let.ident, let.mod_ssr, let.kod_ssr);
	fprintf(fw, "|%c|%c|%s|%s|%c", let.F_rules, let.F_type, let.AC_num, let.AC_type, let.w_turbulence);
	fprintf(fw, "|%s|%s|%s|%s", let.com_nav_equip,let.SSR_equip, let.registration_text, let.operator_text);
	fprintf(fw, "|%s|%s|%s", let.STS_text, let.remark_text, let.adep);
	fprintf(fw, "|%s|%s", let.etd, let.take_off_RWY);
	fprintf(fw, "|%s|%s|%s|%s", let.entry_point, let.entry_time, let.cruising_speed, let.requested_FL); 
	fprintf(fw, "|%s|%s|", let.ades, let.eet);
	fprintf(fw, "%s", let.landing_RWY);
	fprintf(fw, "|%s|%s|%s|\n", let.exit_point, let.exit_time, let.route_length );


	i=0;
	porcis = 0;

	while (1) {
		j=0;
		while ((c = let.route[i]) != '/') bod[j++] = let.route[i++]; 
		bod[j] = '\0';
		//FP 
		//printf(" bod:%s\n", bod);

		i++;
		i++;
		j = 0;
		while ((c = let.route[i]) != '/') level[j++] = let.route[i++];
		level[j] = '\0';

		i++;
		j = 0;
		while ((c = let.route[i]) != ' ' && c != '\0') time[j++] = let.route[i++];
		time[j] = '\0';

		urob_hodiny(time);
		fprintf(fw1, "%d|%d|%s|%s|%s|\n", n, porcis++, bod, level, time);

		if (c == '\0') break;
		else {
			i++;
			if (let.route[i] == '\0') break;
		}
	}

	return 0;
}
//==============================================================================
// urob_datum() expands date from 'DDMMYY' to 'DD.MM.YYYY'
urob_datum(char *dat, char *zdroj)
{
	int i;
	char den[3],mes[3],rok[3];
	sscanf( zdroj, "%2s%2s%2s", den, mes, rok);
	if ( strcmp( rok, "97" ) > 0 )
		sprintf ( dat, "%s.%s.19%s",den, mes, rok );
	else
		sprintf ( dat, "%s.%s.20%s", den, mes, rok ); 
	return 0;
}
//==============================================================================
// daj_datum() calculates the day before today (i.e. yesterday's date)
int daj_datum(char *vcera)         /* vypocita vcerajsi datum v tvare */
{
	time_t t;
	long i, *pi;
	struct tm  *ptmm,tmm;
	int den,mes,rok;
	char cden[3], cmes[3], crok[3];

	// 86400 = 24 * 60 * 60 = number of second in 1 day
	i = time(&t) - 86400;
	pi = &i;
	ptmm = gmtime(pi);

	den = (*ptmm).tm_mday;
	itoa(den, cden);
	mes = 1 + (*ptmm).tm_mon;
	itoa(mes, cmes);
	rok = (*ptmm).tm_year;
	itoa(rok - 100, crok);
	sprintf(vcera, "%s%s%s", cden, cmes, crok);
	return 0;
}

//==============================================================================
// itoa(n,s) converts integer n to string s
itoa(int n, char s[]) {
	int i, sign;

	// uchovaj znamienko n kladne
	if ((sign = n ) < 0) n = -n;

	i=0;
	do {                     /*  generuj cislice v opacnom poradi */

		s[i++] = (n - (n /10) * 10) + 48 ;  /* vezmi dalsiu cislicu */

	} while ((n /= 10 ) > 0);  /* vymaz ju */

	if (sign < 0) s[i++] = '-';
	s[i] = '\0';
	if (strlen(s) == 1) strcat( s, "0" );
	reverse(s);
}
//==============================================================================
// reverse(s) turns the 1st character to the last, etc.
reverse(s)           /* obratenie retazca  */
char s[];
{
	int c, i, j;

	for (i = 0, j = strlen(s)-1; i < j; i++, j--) {
		c = s[i];
		s[i] = s[j];
		s[j] = c;
	}
}
//==============================================================================
// urob_hodiny(cas) expands cas in form 'HHMM' to form 'HH:MM'
urob_hodiny(char cas[]) {
	char pom[6];

	pom[0] = cas[0];
	pom[1] = cas[1];
	pom[2] = ':';
	pom[3] = cas[2];
	pom[4] = cas[3];
	pom[5] = '\0';

	strcpy(cas, pom);
	return 0;
}
//==============================================================================
// change date from 'DDMMYY' to 'YYMMDD'
int obrat_datum(char *s)
{
	char t[10];

	t[0] = s[4];
	t[1] = s[5];
	t[2] = s[2];
	t[3] = s[3];
	t[4] = s[0];
	t[5] = s[1];
	t[6] = '\0';

	strcpy(s, t);

	return 0;
}
//==============================================================================
// arigth(s,i) returns the right part of string s from index i
// actually it cuts first i characters off the string s
int aright(char s[], int i) {
	int j;
	char t[800];

	j = 0;

	while (s[i] != '\0') t[j++] = s[i++]; 
	t[j] = '\0';
	strcpy(s, t);

	return 0;
}

//==============================================================================
// in case of error show an error message and quit the program
int chyba(int i) {
	FILE *flog;

	flog=fopen(LogFile, "a");

	if (i == 1)
		fprintf(flog, "Prilis dlhy retazec v polozke REG letu %s\n", let.ident);

	if (i == 2)
		fprintf(flog, "Nemozem otvorit vystupny subor\n");

	if (i == 3)
		fprintf(flog, "Nemozem otvorit vstupny subor\n");

	fclose(flog);

	exit(1);
}
